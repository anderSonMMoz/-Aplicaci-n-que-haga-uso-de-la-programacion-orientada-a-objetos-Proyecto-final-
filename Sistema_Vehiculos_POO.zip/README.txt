SISTEMA DE VEHÍCULOS - C#

Este proyecto fue creado para demostrar los cuatro principios fundamentales de la
Programación Orientada a Objetos:

1. ENCAPSULAMIENTO
   La clase Vehiculo protege los campos marca y modelo mediante propiedades con
   acceso controlado.

2. ABSTRACCIÓN
   Vehiculo es una clase abstracta y contiene el método abstracto Mover(), que
   obliga a las clases derivadas a definir su propio comportamiento.

3. HERENCIA
   Automovil, Motocicleta y Camion heredan de la clase Vehiculo.

4. POLIMORFISMO
   Los métodos Mover() y MostrarInformacion() son sobrescritos en las clases
   derivadas. El programa puede trabajar con referencias de tipo Vehiculo y cada
   objeto ejecuta su comportamiento correspondiente.

ARCHIVOS:
- Vehiculo.cs
- Automovil.cs
- Motocicleta.cs
- Camion.cs
- Program.cs

El programa NO es un sistema funcional de gestión. Es únicamente un conjunto de
clases y un programa principal que utiliza esas clases, tal como solicita la tarea.

Para ejecutarlo:
1. Crear un proyecto de consola de C# en Visual Studio.
2. Agregar estos archivos al proyecto.
3. Ejecutar el proyecto.
