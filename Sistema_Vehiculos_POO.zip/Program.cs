using SistemaVehiculosPOO;

class Program
{
    static void Main()
    {
        Console.WriteLine("=== SISTEMA DE VEHÍCULOS - PROGRAMACIÓN ORIENTADA A OBJETOS ===");
        Console.WriteLine();

        // Crear objetos de las diferentes clases.
        Vehiculo automovil = new Automovil("Toyota", "Corolla", 4);
        Vehiculo motocicleta = new Motocicleta("Honda", "CBR 500R", true);
        Vehiculo camion = new Camion("Volvo", "FH", 18);

        // Polimorfismo:
        // La misma referencia de tipo Vehiculo ejecuta el comportamiento
        // correspondiente a cada objeto.
        Vehiculo[] vehiculos = { automovil, motocicleta, camion };

        foreach (Vehiculo vehiculo in vehiculos)
        {
            vehiculo.MostrarInformacion();
            vehiculo.Mover();
            Console.WriteLine();
        }

        Console.WriteLine("Principios POO utilizados:");
        Console.WriteLine("- Encapsulamiento: propiedades Marca y Modelo controlan el acceso a los datos.");
        Console.WriteLine("- Abstracción: Vehiculo es una clase abstracta que define Mover().");
        Console.WriteLine("- Herencia: Automovil, Motocicleta y Camion heredan de Vehiculo.");
        Console.WriteLine("- Polimorfismo: Mover() y MostrarInformacion() tienen comportamientos diferentes.");
    }
}
