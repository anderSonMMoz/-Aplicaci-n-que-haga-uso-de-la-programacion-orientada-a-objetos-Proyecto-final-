namespace SistemaVehiculosPOO;

public abstract class Vehiculo
{
    // Encapsulamiento: los datos se mantienen protegidos mediante propiedades privadas.
    private string marca;
    private string modelo;

    public string Marca
    {
        get { return marca; }
        set
        {
            if (!string.IsNullOrWhiteSpace(value))
                marca = value;
        }
    }

    public string Modelo
    {
        get { return modelo; }
        set
        {
            if (!string.IsNullOrWhiteSpace(value))
                modelo = value;
        }
    }

    public Vehiculo(string marca, string modelo)
    {
        Marca = marca;
        Modelo = modelo;
    }

    // Abstracción: cada vehículo debe definir cómo se desplaza.
    public abstract void Mover();

    public virtual void MostrarInformacion()
    {
        Console.WriteLine($"Marca: {Marca} | Modelo: {Modelo}");
    }
}
