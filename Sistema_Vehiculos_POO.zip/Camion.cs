namespace SistemaVehiculosPOO;

// Herencia: Camion hereda de Vehiculo.
public class Camion : Vehiculo
{
    public double CapacidadToneladas { get; set; }

    public Camion(string marca, string modelo, double capacidadToneladas)
        : base(marca, modelo)
    {
        CapacidadToneladas = capacidadToneladas;
    }

    // Polimorfismo: otra implementación de Mover().
    public override void Mover()
    {
        Console.WriteLine("El camión se desplaza transportando carga.");
    }

    public override void MostrarInformacion()
    {
        Console.WriteLine($"Camión: {Marca} {Modelo} | Capacidad: {CapacidadToneladas} toneladas");
    }
}
