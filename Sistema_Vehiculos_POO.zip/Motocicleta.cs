namespace SistemaVehiculosPOO;

// Herencia: Motocicleta también hereda de Vehiculo.
public class Motocicleta : Vehiculo
{
    public bool TieneMaletero { get; set; }

    public Motocicleta(string marca, string modelo, bool tieneMaletero)
        : base(marca, modelo)
    {
        TieneMaletero = tieneMaletero;
    }

    // Polimorfismo: comportamiento diferente para Mover().
    public override void Mover()
    {
        Console.WriteLine("La motocicleta se desplaza por la carretera.");
    }

    public override void MostrarInformacion()
    {
        Console.WriteLine($"Motocicleta: {Marca} {Modelo} | Maletero: {(TieneMaletero ? "Sí" : "No")}");
    }
}
