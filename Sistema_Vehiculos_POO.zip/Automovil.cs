namespace SistemaVehiculosPOO;

// Herencia: Automovil hereda de Vehiculo.
public class Automovil : Vehiculo
{
    public int CantidadPuertas { get; set; }

    public Automovil(string marca, string modelo, int cantidadPuertas)
        : base(marca, modelo)
    {
        CantidadPuertas = cantidadPuertas;
    }

    // Polimorfismo: implementación propia del método abstracto.
    public override void Mover()
    {
        Console.WriteLine("El automóvil se desplaza por la carretera.");
    }

    public override void MostrarInformacion()
    {
        Console.WriteLine($"Automóvil: {Marca} {Modelo} | Puertas: {CantidadPuertas}");
    }
}
